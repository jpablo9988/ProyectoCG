/*
 * =====================================================================================
 *
 *       Filename:  main.cpp
 *
 *    Description:  BtOgre test application, main file.
 *
 *        Version:  1.0
 *        Created:  01/14/2009 05:48:31 PM, Modified: 02/06/2021
 *
 *         Author:  Basado en Archivo de Prueba por : Nikhilesh (nikki)
 *         Modificado por Juan Pablo Amorocho, Aldemar Yamid, Santiago Jaramillo, Sebastian ______
                            para projecto de Intro. a Computaci�n Gr�fica.
 *
 * =====================================================================================
 */
#define _USE_MATH_DEFINES

#include "OgreApplicationContext.h"
#include <OgreInput.h>
#include <OgreRenderWindow.h>
#include <OgreRoot.h>
#include <OgreSceneNode.h>
#include <OgreTrays.h>
#include <OgreCamera.h>
#include "OgreCameraMan.h"
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <iostream>
#include <Windows.h>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "conio.h"
#include <cmath>
#include "BtOgre.h"


using namespace Ogre;
using namespace std;
using namespace OgreBites;

/*
 * =====================================================================================
 *        Class:  BtOgreTestApplication
 *  Description:  Derives from ExampleApplication and overrides stuff.
 * =====================================================================================
 */

class BtOgreTestApplication : public OgreBites::ApplicationContext, public OgreBites::InputListener, public OgreBites::TrayListener
{
    
	 //=============================================ENTIDADES DE CLASE GLOBALES:====================================================//
	std::unique_ptr<BtOgre::DynamicsWorld> mDynWorld;
	//TRAYMANAGER - Manejador de UI.
	OgreBites::TrayManager* mTrayMgr;
	//SCENEMANAGER - Mi escena principal.
	Ogre::SceneManager* mSceneMgr;
	//VIEWPORT - Manejador de Camaras:
	Ogre::Viewport* vp;
	//CAMERA - Mi camara para Debugs.
	Ogre::Camera* mCamera;
	//CAMERA - Camara Jugador 1
	Ogre::SceneNode* nodoCamaraP1;
	Ogre::Camera* camaraP1;
	//CAMERA - Camara Jugador 2
	Ogre::SceneNode* nodoCamaraP2;
	Ogre::Camera* camaraP2;
	//INPUTLISTENERCHAIN - Registrar multiples Input Listeners - CURRENT: CameraMan y TrayListener
	OgreBites::InputListenerChain mInputListners;
	//BONE
	Ogre::Bone* hand;
	//MY RIGIDBODIES OF VARIOUS OBJECTS:
	btRigidBody* bananoR;
	btRigidBody* ogroR;
	btRigidBody* ogro2R;
	btRigidBody* mapaR;

	//Nuestros Proyectiles - Son dos? Mejor Instanciarlos.
	Ogre::SceneNode *mNinjaNode;
	Ogre::Entity *mNinjaEntity;
	Ogre::SceneNode* mNinja2Node;
	Ogre::Entity* mNinja2Entity;

	//Nuestros PJs - Son dos:
	Ogre::SceneNode* mOgroNode;
	Ogre::Entity* mOgroEntity;
	Ogre::SceneNode* mOgro2Node;
	Ogre::Entity* mOgro2Entity;

	//Nuestra entidad de piso.
	Ogre::Entity *mGroundEntity;
	//Nodo de escena que contiene como hijos: Ogro y su Camara asignada mas otros elementos asociados con el jugador
	Ogre::SceneNode* masterPlayer1;
	Ogre::SceneNode* masterPlayer2;

	Button* btnStartSetUp;
	Button* btnExit;
	Button* btnStartGame;
	Button* btnBack;

	Ogre::Bone* neck;
	// Nos dice el turno del ogro. P1 -> false, P2 -> true
	bool turno = true;
	//Nos dice si va a lanzar...Activado con F2
	bool boolwillShoot = false;
	int cameraRotatedOverY = 0, cameraRotatedOverX = 0, camera2RotatedOverX =0;
	OgreBites::CameraMan *mCamMan;
	//Contador global de vidas:
	int vidas1 = 3;
	int vidas2 = 3;

	String nombre1 = "Gorilla 1";
	String nombre2 = "Gorilla 2";

	bool hasGameStarted = false;

	bool mDebugOn;
    std::unique_ptr<BtOgre::DebugDrawer> mDbgDraw;
	/*STRUCT of results in Callback for PLAYER 1
	*/

	struct OgroContactResultCallback : public btCollisionWorld::ContactResultCallback {

		OgroContactResultCallback(BtOgreTestApplication* ptr) : context(ptr) {}

		btScalar addSingleResult(btManifoldPoint& cp,
			const btCollisionObjectWrapper* colObj0Wrap,
			int partId0,
			int index0,
			const btCollisionObjectWrapper* colObj1Wrap,
			int partId1,
			int index1)
		{
			if (context->turno) {
				context->retirarOgro(false);
				context->mostrarVidas(false);
				context->validarGanador();
			}
			_cprintf("\n-------------------GOLPEO 1------------------------");
			return 0;
		}

		BtOgreTestApplication* context;

	};
	/*STRUCT of results in Callback for PLAYER 2
	*/
	struct Ogro2ContactResultCallback : public btCollisionWorld::ContactResultCallback {

		Ogro2ContactResultCallback(BtOgreTestApplication* ptr) : context(ptr) {}

		btScalar addSingleResult(btManifoldPoint& cp,
			const btCollisionObjectWrapper* colObj0Wrap,
			int partId0,
			int index0,
			const btCollisionObjectWrapper* colObj1Wrap,
			int partId1,
			int index1)
		{
			if (!context->turno) {
				context->retirarOgro(true);
				context->mostrarVidas(true);
				context->validarGanador();
			}
			_cprintf("\n-------------------GOLPEO 2------------------------");
			return 0;
		}

		BtOgreTestApplication* context;

	};
	/*STRUCT of results in Callback for either player IF IT HITS THE MAP!
	*/
	struct MapaContactResultCallback : public btCollisionWorld::ContactResultCallback {

		MapaContactResultCallback(BtOgreTestApplication* ptr) : context(ptr) {}

		btScalar addSingleResult(btManifoldPoint& cp,
			const btCollisionObjectWrapper* colObj0Wrap,
			int partId0,
			int index0,
			const btCollisionObjectWrapper* colObj1Wrap,
			int partId1,
			int index1)
		{
			_cprintf("\n-------------------CAMBIOOOOOOOO------------------------");
			context->cambiarTurno();
			return 0;
		}

		BtOgreTestApplication* context;

	};

	//=============================================End - VARIABLES DE CLASE GLOBALES:=================================================//
	
    public:
	BtOgreTestApplication() : OgreBites::ApplicationContext("BtOgre")
	{
        mDynWorld.reset(new BtOgre::DynamicsWorld(Ogre::Vector3(0,-9.8,0)));
		mDebugOn = true;
	}

	void shutdown()
	{
		OgreBites::ApplicationContext::shutdown();
        mDbgDraw->clear();
		delete mTrayMgr;
		delete mCamMan;
	}
	/*
	* Hace un setup de la camara que recibe. 
	*/
	void setCameraInScreen()
	{
		if (!turno)
		{
			vp->setCamera(camaraP1);
		}
		else
		{
			vp->setCamera(camaraP2);
		}
	}

	void rotateCameraToDirection(int unitaryX, int unitaryY)
	{
		if (((unitaryX >= -1) && (unitaryX <= 1) && ((unitaryY >= -1) && (unitaryY <= 1))))
		{

				if (!this->turno)
				{
					//nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(unitaryX * 3), Ogre::Vector3(1, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
					nodoCamaraP1->rotate(Ogre::Vector3(1,0,0), Ogre::Radian(unitaryX * 0.05));

					this->cameraRotatedOverX += unitaryX * 3;
					nodoCamaraP1->rotate(Ogre::Vector3(0, 1, 0), Ogre::Radian(unitaryY * 0.05));
					//nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(unitaryY * 3), Ogre::Vector3(0, 1, 0)), Ogre::Node::TransformSpace::TS_WORLD);
					this->cameraRotatedOverY += unitaryY * 3;
				}
			
		}
	}
	/* setCameraPosition()
	*  setea la posici�n inicial de las dos camaras en relaci�n al Ogro!
	*/ 
	void setRotations()
	{
		if (boolwillShoot == true)
		{
			nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(50), Ogre::Vector3(1, 0, 0)));
			nodoCamaraP2->rotate(Ogre::Quaternion(Ogre::Degree(-50), Ogre::Vector3(1, 0, 0)));
		}
		else
		{
			nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(-cameraRotatedOverX), Ogre::Vector3(1, 0, 0)));
			nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(-cameraRotatedOverY), Ogre::Vector3(0, 1, 0)));
			nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(-50), Ogre::Vector3(1, 0, 0)));
			nodoCamaraP2->rotate(Ogre::Quaternion(Ogre::Degree(50), Ogre::Vector3(1, 0, 0)));
			cameraRotatedOverX = 0;
			cameraRotatedOverY = 0;
		}
	}
	void setCameraPOV()
	{
		Ogre::Vector3 miVector;
		
		Ogre::Real offsetX = 0, offsetY = 0, offsetZ = 0;
		if (!turno)
		{
			Ogre::Vector3 miVector = mOgroNode->getPosition(); //Consigo posici�n de mi Ogro
			//Ajusto el offset vs el ogro
			miVector.x += offsetX;
			miVector.y += offsetY;
			miVector.z += offsetZ;
			//Ajusto la posici�n de la camara!
			this->nodoCamaraP1->setPosition(miVector);
		}
		else
		{

			miVector = mOgro2Node->getPosition();
			miVector.x -= offsetX;
			miVector.y += offsetY;
			miVector.z -= offsetZ;
			nodoCamaraP2->setPosition(miVector);

		}

		setCameraInScreen();

	}
	
	/* Nos calcula las fuerzas de lanzamiento con un angulo y las propiedades de pit�goras
	*/
	Ogre::Vector3 getFuerzaLanzamiento(float f0)
	{
		Ogre::Vector3 miVector;
		float theta = (float)this->cameraRotatedOverX * ((float)M_PI / 180);
		miVector.x = cos(theta) * f0;
		miVector.y = sin(theta) * f0;
		miVector.z = 0.0;
		return miVector;

	}
	void setCameraPosition()
	{
		Ogre::Vector3 miVector;
		
		Ogre::Real offsetX = 0, offsetY = 10, offsetZ = 15;
			if (!turno)
			{
				Ogre::Vector3 miVector = mOgroNode->getPosition(); //Consigo posici�n de mi Ogro
				//Ajusto el offset vs el ogro
				miVector.x += offsetX;
				miVector.y += offsetY;
				miVector.z += offsetZ;
				//Ajusto la posici�n de la camara!
				this->nodoCamaraP1->setPosition(miVector);
			}
			else
			{

				miVector = mOgro2Node->getPosition();
				miVector.x -= offsetX;
				miVector.y += offsetY;
				miVector.z -= offsetZ;
				nodoCamaraP2->setPosition(miVector);

			}

			setCameraInScreen();

	}
	/* setupCameras()
	* Esta funci�n inicializa las dos camaras que seguiran a los jugadores...
	* Una camara tiene su SceneNode asignado
	* Tambien se asignan la rotaci�n "default" de las camaras en cuesti�n.
	*/
	void setupCameras()
	{
		// Creaci�n de Camaras del Jugador:

		this->nodoCamaraP1 = mSceneMgr->getRootSceneNode()->createChildSceneNode();
		this->camaraP1 = mSceneMgr->createCamera("camPlayer1");
		this->camaraP1->setAutoAspectRatio(true);
		this->camaraP1->setNearClipDistance(0.05);
		this->nodoCamaraP2 = mSceneMgr->getRootSceneNode()->createChildSceneNode();
		this->camaraP2 = mSceneMgr->createCamera("camPlayer2");
		this->camaraP2->setAutoAspectRatio(true);
		this->camaraP2->setNearClipDistance(0.05);

		// Asociacion del padre SceneNode y el hijo Camara:
		this->nodoCamaraP1->attachObject(camaraP1);
		this->nodoCamaraP2->attachObject(camaraP2);
		
		//Rotaci�n Inicial de las Camaras:
		nodoCamaraP2->rotate(Ogre::Quaternion(Ogre::Degree(180), Ogre::Vector3(0, 1, 0)), Ogre::Node::TransformSpace::TS_WORLD);
		//nodoCamaraP2->rotate(Ogre::Quaternion(Ogre::Degree(0), Ogre::Vector3(0, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
		nodoCamaraP2->rotate(Ogre::Quaternion(Ogre::Degree(40), Ogre::Vector3(1, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
		nodoCamaraP1->rotate(Ogre::Quaternion(Ogre::Degree(-40), Ogre::Vector3(1, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
		

		// - END -

	}



	/* setup
	* Estado inicial del juego.
	*/
	void setup(void)
	{
	    OgreBites::ApplicationContext::setup();
	    addInputListener(this);

	    mSceneMgr = getRoot()->createSceneManager();

	    // register our scene with the RTSS
	    Ogre::RTShader::ShaderGenerator* shadergen = Ogre::RTShader::ShaderGenerator::getSingletonPtr();
	    shadergen->addSceneManager(mSceneMgr);

	    // without light we would just get a black screen
        Ogre::Light* light = mSceneMgr->createLight("MainLight");
        Ogre::SceneNode* lightNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
        lightNode->setPosition(0, 10, 15);
        lightNode->attachObject(light);

	    // create the camera Debug:
	    mCamera = mSceneMgr->createCamera("myCam");
	    mCamera->setAutoAspectRatio(true);
		Ogre::SceneNode* camnode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
		camnode->attachObject(mCamera);
		
		mCamMan = new OgreBites::CameraMan(camnode);
		mCamMan->setStyle(OgreBites::CS_ORBIT);
		mCamMan->setYawPitchDist(Ogre::Degree(45), Ogre::Degree(45), 40);
		
		mCamera->setNearClipDistance(0.05);


		
		mTrayMgr = new OgreBites::TrayManager("Interface", getRenderWindow(), this);
		mSceneMgr->addRenderQueueListener(getOverlaySystem());
		mInputListners = OgreBites::InputListenerChain({ mTrayMgr});
		addInputListener(&mInputListners);
		
		

		setupCameras(); //Funcion que setea cameras de Usuario...

	    

	    // and tell it to render into the main window
	    vp = getRenderWindow()->addViewport(mCamera);


	    //Some normal stuff.
	    mSceneMgr->setAmbientLight(ColourValue(0.7,0.7,0.7));

	   
	    LogManager::getSingleton().setLogDetail(LL_BOREME);

	    //----------------------------------------------------------
	    // Debug drawing!
	    //----------------------------------------------------------

	    mDbgDraw.reset(new BtOgre::DebugDrawer(mSceneMgr->getRootSceneNode(), mDynWorld->getBtWorld()));

	    //----------------------------------------------------------
	    // Ninja!
	    //----------------------------------------------------------

		//Creaci�n de mis entidades-> Ogros y Bananos
	    mNinjaEntity = mSceneMgr->createEntity("ninjaEntity", "Player.mesh");
	    mNinjaNode = mSceneMgr->getRootSceneNode()->createChildSceneNode(Vector3(0,10,0));
	    mNinjaNode->attachObject(mNinjaEntity);
		/*
		mNinja2Entity = mSceneMgr->createEntity("ninja2Entity", "Player.mesh");
		mNinja2Node = mSceneMgr->getRootSceneNode()->createChildSceneNode(Vector3(10, 10, 10));
		mNinja2Node->attachObject(mNinja2Entity);
		*/

		mOgroEntity = mSceneMgr->createEntity("ogroEntity", "Sinbad.mesh");
		mOgroNode = mSceneMgr->getRootSceneNode()->createChildSceneNode(Vector3(10, 5, 10));
		mOgroNode->attachObject(mOgroEntity);

		mOgroNode->scale(Ogre::Vector3(0.4, 0.4, 0.4));

		mOgro2Entity = mSceneMgr->createEntity("ogro2Entity", "Sinbad.mesh");
		mOgro2Node = mSceneMgr->getRootSceneNode()->createChildSceneNode(Vector3(-10, 5, -10));
		mOgro2Node->attachObject(mOgro2Entity);

		mOgro2Node->scale(Ogre::Vector3(0.4, 0.4, 0.4));

		mOgroNode->rotate(Ogre::Quaternion(Ogre::Degree(180), Ogre::Vector3(0, 1, 0)), Ogre::Node::TransformSpace::TS_WORLD);

		Ogre::SkeletonInstance* skl = mOgro2Entity->getSkeleton();
			

		ubicarOgros();

		

	    //Create the Body.
        //mDynWorld->addRigidBody(5, mNinjaEntity, BtOgre::CT_SPHERE);
		//mDynWorld->addRigidBody(5, mNinja2Entity, BtOgre::CT_SPHERE);
		ogroR = mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
		ogro2R = mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);

	    //----------------------------------------------------------
	    // Ground!
	    //----------------------------------------------------------
		//Create Ogre stuff.
		mGroundEntity = mSceneMgr->createEntity("groundEntity", "TestLevel_b0.mesh");
		mSceneMgr->getRootSceneNode()->createChildSceneNode("groundNode")->attachObject(mGroundEntity);

		//Create the Body.
		mapaR = mDynWorld->addRigidBody(0, mGroundEntity, BtOgre::CT_TRIMESH);
		//mSceneMgr->setSkyBox(true, "Examples/CloudyNoonSkyBox");
	    

		//createMainMenu();
		setMainMenu();
	}
	void setMainMenu() {
		mTrayMgr->showBackdrop();
		createMainMenu();
		mOgroNode->flipVisibility();
		mOgro2Node->flipVisibility();
		mNinjaNode->flipVisibility();
		ogroR->activate(false);
		ogro2R->activate(false);
		
	}
	void startGame()
	{
		// CLEAR MENU:
		mTrayMgr->destroyWidget("LabelSetupMenu");
		mTrayMgr->destroyWidget("Try");
		btnStartGame->hide();
		btnBack->hide();
		mTrayMgr->clearAllTrays();

		//STARTUP - Visibility:
		setRigidBodies();
		mOgroNode->flipVisibility();
		mOgro2Node->flipVisibility();
		mNinjaNode->flipVisibility();
		cambiarTurno();
		this->hasGameStarted = true;
	}
	void setRigidBodies()
	{
		ogroR->activate(true);
		ogro2R->activate(true);
	}
	void createMainMenu()
	{
		mTrayMgr->destroyAllWidgets();
		mTrayMgr->createLabel(OgreBites::TL_CENTER, "LabelMainMenu", "Bienvenidos a bas.Ogre", 400);
		btnStartSetUp = mTrayMgr->createButton(OgreBites::TL_CENTER, "StartSetup", "Start");
		btnExit =  mTrayMgr->createButton(OgreBites::TL_CENTER, "ExitGame", "Salir");
	}
	void createSetupMenu()
	{
		mTrayMgr->destroyWidget("LabelMainMenu");
		btnStartSetUp->hide();
		btnExit->hide();
		mTrayMgr->clearAllTrays();
		btnStartGame =  mTrayMgr->createButton(OgreBites::TL_BOTTOM, "StartGame", "Empieza el Juego!");
		btnBack = mTrayMgr->createButton(OgreBites::TL_BOTTOMLEFT, "BackToMenu", "Atras");
		mTrayMgr->createLabel(OgreBites::TL_CENTER, "LabelSetupMenu", "Escoge los Nombres y Vidas de tus personajes!", 400);
		 mTrayMgr->createTextBox(OgreBites::TL_CENTER, "Try", "a Try", 400,20);
		
		

	}

	void BtOgreTestApplication::buttonHit(OgreBites::Button* b) {

		if (b->getName() == "StartSetup")
		{
			createSetupMenu();
		}
		if (b->getName() == "StartGame")
		{
			startGame();
		}
		if (b->getName() == "BackToMenu")
		{
			createMainMenu();
		}


	}

	void validarGanador() {
		if (vidas1 <= 0 || vidas2 <= 0) {

			char ch;

			_cprintf("\n-------------------------------------------------------");

			if (vidas1 <= 0) {
				_cprintf("\nFelicidades %s !!!", nombre2);
			}
			else if (vidas2 <= 0) {
				_cprintf("\nFelicidades %s !!!", nombre1);
			}

			_cprintf("\nHas ganado :D");
			_cprintf("\n-------------------------------------------------------");

			_cprintf("\nGracias por jugar :D\n");
			_cscanf("%c", &ch);

			// TODO: Cerrar la aplicaci�n o implementar volver a jugar

		}
		else {
			ubicarOgros();
		}
	}

	void mostrarVidas(bool ogro) {

		char ch;

		_cprintf("\n-------------------------------------------------------");

		if (ogro) {
			_cprintf("\nGran Lanzamiento, punto para el %s :D", nombre2);
			vidas1 -= 1;
		}
		else {
			_cprintf("\nGran Lanzamiento, punto para el %s :D", nombre1);
			vidas2 -= 1;
		}

		cambiarTurno();

		_cprintf("\nVidas Mono 1: %d", vidas1);
		_cprintf("\nVidas Mono 2: %d", vidas2);
		_cprintf("\n-------------------------------------------------------");
		_cprintf("\nPresiona una tecla para continuar...\n");

		_cscanf("%c", &ch);

	}

	void retirarOgro(bool ogro) {

		if (ogro) {
			this->mOgro2Node->rotate(Ogre::Quaternion(Ogre::Degree(90), Ogre::Vector3(1, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
			ogro2R = mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);
		}
		else {
			this->mOgroNode->rotate(Ogre::Quaternion(Ogre::Degree(90), Ogre::Vector3(1, 0, 0)), Ogre::Node::TransformSpace::TS_WORLD);
			ogroR = mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
		}

	}

	void ubicarOgros() {

		this->mOgroNode->setPosition(Ogre::Vector3(rand() % (21) - 10, 5, rand() % (6) + 5));
		ogroR = mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);

		this->mOgro2Node->setPosition(Ogre::Vector3(rand() % (21) - 10, 5, -(rand() % (6) + 5)));
		ogro2R = mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);

	}




	bool keyPressed(const OgreBites::KeyboardEvent& evt)
	{
		int key = evt.keysym.sym;

		using namespace OgreBites;
		// Will only accept keyboard inputs if the game is running!
		if (evt.keysym.sym == SDLK_ESCAPE)
		{
			delete mTrayMgr;
			delete mCamMan;
			getRoot()->queueEndRendering();
		}
		if (key == 'h')
		{
			_cprintf("\nI did it also! \n");
		}
		if (evt.keysym.sym == SDLK_KP_1)
		{
			_cprintf("\nI did it also! \n");
		}
		if (evt.keysym.sym == SDLK_KP_2)
		{
			_cprintf("\nI did it also! \n");
		}
		if (evt.keysym.sym == SDLK_KP_3)
		{
			_cprintf("\nI did it also! \n");
		}
		if (this->hasGameStarted == true)
		{
			
			if (evt.keysym.sym == SDLK_F3)
			{
				mDebugOn = !mDebugOn;

				if (!mDebugOn)
					mDbgDraw->clear();
			}

			else if (evt.keysym.sym == SDLK_LSHIFT)
			{
				throwBanana();

			}
			else if (evt.keysym.sym == SDLK_UP)
			{
				if (boolwillShoot == true)
				{
					this->rotateCameraToDirection(1, 0);
				}
				else
				{
					if (this->turno) {
						this->mOgro2Node->translate(Ogre::Vector3(0, 0, 1));
						mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);
						setCameraPosition();

					}
					else {
						this->mOgroNode->translate(Ogre::Vector3(0, 0, -1));
						mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
						setCameraPosition();

					}
				}
				agarrarPelota();

			}
			else if (evt.keysym.sym == SDLK_DOWN)
			{
				if (boolwillShoot == true)
				{
					this->rotateCameraToDirection(-1, 0);
				}
				else
				{
					if (this->turno) {
						this->mOgro2Node->translate(Ogre::Vector3(0, 0, -1));
						mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);
						setCameraPosition();

					}
					else {
						this->mOgroNode->translate(Ogre::Vector3(0, 0, 1));
						mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
						setCameraPosition();

					}
				}
				agarrarPelota();
			}
			else if (evt.keysym.sym == SDLK_RIGHT)
			{
				if (boolwillShoot == false)
				{

					if (this->turno) {
						this->mOgro2Node->translate(Ogre::Vector3(-1, 0, 0));
						mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);
						setCameraPosition();

					}
					else
					{
						this->mOgroNode->translate(Ogre::Vector3(1, 0, 0));
						mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
						setCameraPosition();

					}
				}
				agarrarPelota();

			}
			else if (evt.keysym.sym == SDLK_LEFT)
			{
				if (boolwillShoot == false)
				{


					if (this->turno) {
						this->mOgro2Node->translate(Ogre::Vector3(1, 0, 0));
						mDynWorld->addRigidBody(5, mOgro2Entity, BtOgre::CT_BOX);
						setCameraPosition();

					}
					else {
						this->mOgroNode->translate(Ogre::Vector3(-1, 0, 0));
						mDynWorld->addRigidBody(5, mOgroEntity, BtOgre::CT_BOX);
						setCameraPosition();

					}
				}
				agarrarPelota();

			}
			else if (evt.keysym.sym == SDLK_SPACE)
			{
				if (boolwillShoot == true)
				{
					boolwillShoot = false;
					setRotations();
					setCameraPosition();
				}
				else
				{
					this->turno = !this->turno; //TESTING PURPOSES!
					setCameraPosition();
				}
			}
			else if (evt.keysym.sym == SDLK_F1)
			{
				setCameraPosition();
			}
			else if (evt.keysym.sym == SDLK_F2)
			{

				if (boolwillShoot == false)
				{
					this->mOgroNode->flipVisibility();
					boolwillShoot = true;
					setRotations();
					setCameraPOV();
				}
				else if (boolwillShoot == true)
				{
					this->mOgroNode->flipVisibility();
					boolwillShoot = false;
					setRotations();
					setCameraPosition();
				}
			}
		}

	    return true;
	}

	void throwBanana()
	{
		//this->neck->pitch(Ogre::Radian(0.1));	
			//hand->removeChild("mNinjaNode");

		this->bananoR = mDynWorld->addRigidBody(5, mNinjaEntity, BtOgre::CT_SPHERE);
		this->bananoR->setActivationState(1);

		double direccion[3] = { 0.0, 0.0, 0.0 };
		double potencia = 5;

		

		/*
		_cprintf("\nIngrese el vector de direcci�n (separado por espacios - Doubles): \n");
		_cscanf("%lf %lf %lf", &direccion[0], &direccion[1], &direccion[2]);
		*/
		
		_cprintf("\n Capitan, estamos en un angulo de: ");
		_cprintf("%i", this->cameraRotatedOverX);
		_cprintf("\nIngrese la potencia del disparo (Double): \n");
		_cscanf("%lf", &potencia);


		Ogre::Vector3 miForces = getFuerzaLanzamiento(potencia);

		boolwillShoot = false;
		setRotations();
		setCameraPosition();

		this->mOgroNode->flipVisibility();

		if (!turno)
		{
			this->bananoR->applyCentralImpulse(btVector3(miForces.z, miForces.y, -miForces.x));
			_cprintf("\nResultados de fuerzas (x,y):");
			_cprintf("%f", miForces.x);
			_cprintf("%f", miForces.y);
		}
		else
		{
			this->bananoR->applyCentralImpulse(btVector3(miForces.z, -miForces.y, miForces.x));
		}
		// Lo que hay que arreglar:
		if (turno) {
			//Ogro2ContactResultCallback callbackOgro2(this);
			//mDynWorld->getBtWorld()->contactPairTest(bananoR, ogro2R, callbackOgro2);
		}
		else {
			//OgroContactResultCallback callbackOgro(this);
			//mDynWorld->getBtWorld()->contactPairTest(bananoR, ogroR, callbackOgro);
		}

		//MapaContactResultCallback callbackMapa(this);
		//mDynWorld->getBtWorld()->contactPairTest(bananoR, mapaR, callbackMapa);
	}

    bool frameStarted(const FrameEvent &evt)
    {
        OgreBites::ApplicationContext::frameStarted(evt);

        //Update Bullet world. Don't forget the debugDrawWorld() part!
        mDynWorld->getBtWorld()->stepSimulation(evt.timeSinceLastFrame, 10);

        if(mDebugOn)
        	mDbgDraw->update();

        return true;
    }
	void agarrarPelota() {
		if (this->turno) {
			Ogre::SkeletonInstance* skl = mOgro2Entity->getSkeleton();
			hand = skl->getBone("Hand.R");
			/*hand->setManuallyControlled(true);*/
			//hand->addChild(mNinjaNode);
			//_cprintf("MANO POSICION: %lf, %lf, %lf", hand->_getDerivedPosition()[0] + mOgro2Node->getPosition()[0], hand->_getDerivedPosition()[1] + mOgro2Node->getPosition()[1], hand->_getDerivedPosition()[2] + +mOgro2Node->getPosition()[2]);
			//mNinjaNode->setPosition(hand->_getDerivedPosition() + mOgro2Node->getPosition());		
			mNinjaNode->setPosition(mOgro2Node->getPosition());
			//mNinjaNode->setPosition(hand->getPosition());
			mNinjaNode->translate(Ogre::Vector3(0, 0, 2));
		}
		else {
			Ogre::SkeletonInstance* skl = mOgroEntity->getSkeleton();
			hand = skl->getBone("Hand.R");
			/*hand->setManuallyControlled(true);*/
			//hand->addChild(mNinjaNode);
			//_cprintf("MANO POSICION: %lf, %lf, %lf", hand->_getDerivedPosition()[0] + mOgroNode->getPosition()[0], hand->_getDerivedPosition()[1] + mOgroNode->getPosition()[1], hand->_getDerivedPosition()[2] + +mOgroNode->getPosition()[2]);
			//mNinjaNode->setPosition(hand->_getDerivedPosition() + mOgroNode->getPosition());
			//mNinjaNode->setPosition(obtenerPosManoR(mOgroNode->getPosition()));
			mNinjaNode->setPosition(mOgroNode->getPosition());
			//mNinjaNode->setPosition(hand->getPosition());
			mNinjaNode->translate(Ogre::Vector3(0, 0, -2));
		}

	}
	void cambiarTurno() {
		this->turno = !this->turno;
		if (mDynWorld->getBtWorld()->getCollisionObjectArray().size() > 3) {
			//mDynWorld->getBtWorld()->removeCollisionObject(mDynWorld->getBtWorld()->getCollisionObjectArray()[3]);
		}
		if (boolwillShoot == true)
		{
			boolwillShoot = false;
			setRotations();
			setCameraPosition();
		}
		setCameraPosition();
		agarrarPelota();

	}

	Ogre::Vector3 GetBoneWorldPosition(Entity* ent, Bone bone)
	{
		Vector3 world_position = bone._getDerivedPosition();

		//multiply with the parent derived transformation
		Node* pParentNode = ent->getParentNode();
		SceneNode* pSceneNode = ent->getParentSceneNode();
		while (pParentNode != NULL)
		{
			//process the current i_Node
			if (pParentNode != pSceneNode)
			{
				//this is a tag point (a connection point between 2 entities). which means it has a parent i_Node to be processed
				/*Ogre::TagPoint* tp = static_cast<Ogre::TagPoint*> (pParentNode);
				world_position = tp->_getFullLocalTransform() * world_position;
				pParentNode = (pParentNode as TagPoint).ParentEntity.ParentNode;*/
			}
			else
			{
				//this is the scene i_Node meaning this is the last i_Node to process
				world_position = pParentNode->_getFullTransform() * world_position;
				break;
			}
		}
		return world_position;
	}

	Ogre::Vector3 obtenerPosManoR(Ogre::Vector3 pos) {
		Ogre::Vector3 suma = Ogre::Vector3(0, 0, 0);
		Ogre::Node* nodo = hand;
		while (nodo->getParent() != NULL) {
			suma = suma + nodo->getPosition();
			nodo = nodo->getParent();
		}
		suma[0] += pos[0];
		suma[1] -= 5;
		suma[2] += pos[2];
		//_cprintf("SUMA: %lf, %lf, %lf", suma[0], suma[1], suma[2]);
		return suma;
	}
};







/*
 * ===  FUNCTION  ======================================================================
 *         Name:  main
 *  Description:  main() function. Need say more?
 * =====================================================================================
 */

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"

INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT)
#else
int main(int argc, char** argv)
#endif
{
	// Create application object
	//showWin32Console();
	AllocConsole();

	BtOgreTestApplication app;
	app.initApp();
	
	app.getRoot()->startRendering();
	app.setup();
	app.closeApp();
	

	FreeConsole();


	return 0;
}
